# Quickstart #8: EntityFramework configuration

This quickstart shows how to use EntityFramework for the configuration data.

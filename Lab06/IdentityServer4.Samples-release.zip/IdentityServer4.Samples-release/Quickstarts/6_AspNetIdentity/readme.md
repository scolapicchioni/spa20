# Quickstart #6: IdentityServer and ASP.NET Identity

This quickstart uses ASP.NET Identity for identity management.

## Tutorial

The tutorial that goes along with this sample can be found here [Using ASP.NET Core Identity](http://docs.identityserver.io/en/release/quickstarts/6_aspnet_identity.html)
